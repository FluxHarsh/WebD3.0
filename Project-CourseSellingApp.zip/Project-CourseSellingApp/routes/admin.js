const { Router } = require("express");
const adminRouter = Router();
const { adminModel, courseModel } = require("../db");
const jwt = require("jsonwebtoken");
const  { JWT_ADMIN_PASSWORD } = require("../config");
const { adminMiddleware } = require("../middleware/admin");
const bcrypt = require('bcrypt')



adminRouter.post("/signup", async function(req, res) {

    const email = req.body.email
    const password = req.body.password
    const firstName = req.body.firstName
    const lastName = req.body.lastName

    const hashedPassword = await bcrypt.hash(password, 10)
    console.log(hashedPassword)

    await adminModel.create({
        email: email,
        password: hashedPassword,
        firstName: firstName,
        lastName: lastName
    })

    console.log(adminModel)

    res.json({
        msg: "Admin successfully signed up"
    })
})

adminRouter.post("/signin", async function(req, res) {

    const email = req.body.email
    const password = req.body.password

    const admin = await adminModel.findOne({
        email: email
    })

    if(!admin){
        res.status(403).json({
            msg:"Admin user doesn't exist in our DB"
        })
    }

    const passwordMatch = await bcrypt.compare(password, admin.password)

    if(passwordMatch) {
        const token = jwt.sign({
            id :admin._id.toString()
        },JWT_ADMIN_PASSWORD)

        res.json({
            token : token
        })
    }else{
        res.status(403).json({
            message:"Invalid credentials either wrong password or email"
        })
    }
})

adminRouter.post("/course", adminMiddleware, async function(req, res) {
    const adminId = req.userId;

    const { title, description, imageUrl, price } = req.body;


    const course = await courseModel.create({
        title: title, 
        description: description, 
        imageUrl: imageUrl, 
        price: price, 
        creatorId: adminId
    })

    res.json({
        message: "Course created",
        courseId: course._id
    })
})

adminRouter.put("/course", adminMiddleware, async function(req, res) {
    const adminId = req.userId;

    const { title, description, imageUrl, price, courseId } = req.body;


    const course = await courseModel.updateOne({
        _id: courseId, 
        creatorId: adminId 
    }, {
        title: title, 
        description: description, 
        imageUrl: imageUrl, 
        price: price
    })

    res.json({
        message: "Course updated",
        courseId: course._id
    })
})

adminRouter.get("/course/bulk", adminMiddleware,async function(req, res) {
    const adminId = req.userId;

    const courses = await courseModel.find({
        creatorId: adminId 
    });

    res.json({
        message: "Course updated",
        courses
    })
})

module.exports = {
    adminRouter: adminRouter
}
